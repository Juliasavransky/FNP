import React, { Component } from 'react';

class help extends Component {
    render() {
        return (
            <div>
                Help me!!!!!
            </div>
        );
    }
}

export default help;